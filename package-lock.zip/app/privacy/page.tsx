import { PrivacyContent } from "@/components/legal/privacy/privacy-content"

export default function Terms() {
  return (
    <main className="">
      <PrivacyContent />
    </main>
  )
}