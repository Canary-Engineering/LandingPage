import { TermsContent } from "@/components/legal/terms/terms-content"

export default function Privacy() {
  return (
    <main className="">
      <TermsContent />
    </main>
  )
}